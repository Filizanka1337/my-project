import tkinter as tk
from pytube import YouTube
from tkinter import filedialog  # Dodajemy obsługę okna dialogowego do wyboru ścieżki
from PIL import Image, ImageTk  # Dodajemy obsługę obrazów

def download_video():
    url = url_entry.get()
    try:
        yt = YouTube(url)
        stream = yt.streams.get_highest_resolution()
        
        # Pobieranie ścieżki od użytkownika
        save_path = filedialog.askdirectory()
        
        if save_path:
            stream.download(output_path=save_path)
            status_label.config(text="Pobieranie zakończone pomyślnie")
        else:
            status_label.config(text="Nie wybrano miejsca zapisu.")
    except Exception as e:
        status_label.config(text="Błąd: " + str(e))

def on_enter_key(event):
    download_video()

# Tworzenie głównego okna
root = tk.Tk()
root.title("Jakiś Pobieracz na ingfo")

# Dodawanie logo YouTube
logo_image = Image.open("data/yt.png")  # Wczytujemy obraz
logo_photo = ImageTk.PhotoImage(logo_image)
logo_label = tk.Label(root, image=logo_photo)
logo_label.image = logo_photo
logo_label.pack()

# Etykieta
label = tk.Label(root, text="Wprowadź URL filmu:")
label.pack()

# Pole do wprowadzenia URL
url_entry = tk.Entry(root, width=40)
url_entry.pack()

# Przycisk do pobierania
download_button = tk.Button(root, text="Pobierz film", command=download_video)
download_button.pack()

# Etykieta do wyświetlania statusu
status_label = tk.Label(root, text="")
status_label.pack()

# Obsługa klawisza Enter
url_entry.bind('<Return>', on_enter_key)

# Uruchamianie głównego pętli tkinter
root.mainloop()
